//
//  AppDelegate.h
//  cosplayisforeveryone
//
//  Created by Luchinda Wollin on 2014-01-03.
//  Copyright (c) 2014 Luchinda Wollin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIViewController *viewController;


@end
